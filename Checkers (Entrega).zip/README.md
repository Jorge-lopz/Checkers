# CHECKERS &nbsp;<img src="https://visitor-badge.laobi.icu/badge?page_id=jorge-lopz.checkers">
Checkers game with 3D graphics and an AI Bot 

## Contributors
<div align="center">
  <br>
  <img src="https://contrib.rocks/image?repo=jorge-lopz/Checkers" />
</div>
